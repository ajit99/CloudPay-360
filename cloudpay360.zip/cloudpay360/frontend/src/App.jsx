// src/App.js
import React, { useEffect, useState } from 'react';
import SockJS from 'sockjs-client';
import Stomp from 'stompjs';
import './App.css';

const App = () => {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    // Connect to WebSocket endpoint (assumed to be provided by Spring Boot backend)
    const socket = new SockJS('http://localhost:8080/ws');
    const stompClient = Stomp.over(socket);

    stompClient.connect({}, (frame) => {
      console.log('Connected: ' + frame);
      // Subscribe to Kafka topic 'payment-events'
      stompClient.subscribe('/topic/payment-events', (message) => {
        const payment = JSON.parse(message.body);
        setPayments((prev) => [...prev, payment]);
      });
    }, (error) => {
      console.error('Connection error: ', error);
    });

    // Cleanup on component unmount
    return () => {
      if (stompClient) stompClient.disconnect();
    };
  }, []);

  return (
    <div className="App">
      <h1>CloudPay 360 Dashboard</h1>
      <h2>Real-Time Payment Updates</h2>
      <ul>
        {payments.map((payment, index) => (
          <li key={index}>
            Order: {payment.orderId} | Amount: {payment.amount} {payment.currency} | Status: {payment.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;