const { useState, useEffect } = React;

function PaymentDashboard() {
    const [payments, setPayments] = useState([]);

    useEffect(() => {
        const socket = new SockJS('http://localhost:8080/ws');
        const stompClient = Stomp.over(socket);

        stompClient.connect({}, () => {
            stompClient.subscribe('/topic/payments', (message) => {
                const payment = JSON.parse(message.body);
                setPayments((prev) => [...prev, payment]);
            });
        });

        return () => {
            stompClient.disconnect();
        };
    }, []);

    return (
        <div>
            <h2 className="text-2xl font-semibold mb-4">Payment Status</h2>
            <table className="min-w-full bg-white border">
                <thead>
                    <tr>
                        <th className="py-2 px-4 border-b">Order ID</th>
                        <th className="py-2 px-4 border-b">Amount</th>
                        <th className="py-2 px-4 border-b">Currency</th>
                        <th className="py-2 px-4 border-b">User ID</th>
                        <th className="py-2 px-4 border-b">Status</th>
                    </tr>
                </thead>
                <tbody>
                    {payments.map((payment) => (
                        <tr key={payment.orderId} className="text-center">
                            <td className="py-2 px-4 border-b">{payment.orderId}</td>
                            <td className="py-2 px-4 border-b">{payment.amount}</td>
                            <td className="py-2 px-4 border-b">{payment.currency}</td>
                            <td className="py-2 px-4 border-b">{payment.userId}</td>
                            <td className="py-2 px-4 border-b">
                                <span className={`inline-block px-2 py-1 rounded ${payment.status === 'APPROVED' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                                    {payment.status}
                                </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}