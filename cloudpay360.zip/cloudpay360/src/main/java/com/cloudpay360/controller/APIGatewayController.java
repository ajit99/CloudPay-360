package com.cloudpay360.controller;

import com.cloudpay360.model.PaymentRequest;
import com.cloudpay360.model.User;
import com.cloudpay360.service.AuthenticationService;
import com.cloudpay360.service.PaymentOrchestratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class APIGatewayController {

    @Autowired
    private AuthenticationService authService;

    @Autowired
    private PaymentOrchestratorService paymentOrchestrator;

    @PostMapping("/payments")
    public ResponseEntity<String> handlePaymentRequest(@RequestBody PaymentRequest request,
                                                      @RequestHeader("Authorization") String token) {
        User user = new User();
        user.setUserId(request.getUserId());
        user.setToken(token);

        if (authService.authenticate(user)) {
            paymentOrchestrator.processPayment(request);
            return ResponseEntity.ok("Payment processed successfully for order: " + request.getOrderId());
        } else {
            return ResponseEntity.status(401).body("Authentication failed for user: " + user.getUserId());
        }
    }
}