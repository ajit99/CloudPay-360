package com.cloudpay360;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudPay360Application {
    public static void main(String[] args) {
        SpringApplication.run(CloudPay360Application.class, args);
    }
}