package com.cloudpay360.service;

import com.cloudpay360.model.PaymentRequest;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class DashboardService {

    @KafkaListener(topics = "payment-events", groupId = "cloudpay360-group")
    public void updateDashboard(PaymentRequest request) {
        System.out.println("Dashboard: Updating UI for order: " + request.getOrderId() +
                ", status: " + request.getStatus());
    }
}