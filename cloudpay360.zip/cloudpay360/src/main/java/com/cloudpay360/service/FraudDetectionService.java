package com.cloudpay360.service;

import com.cloudpay360.model.PaymentRequest;
import org.springframework.stereotype.Service;

@Service
public class FraudDetectionService {

    public boolean analyze(PaymentRequest request) {
        // Simulate real-time fraud detection (e.g., AWS Lambda)
        System.out.println("Analyzing payment for order: " + request.getOrderId());
        // Dummy logic: reject if amount > 10000
        return request.getAmount() <= 10000;
    }
}