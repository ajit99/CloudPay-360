package com.cloudpay360.service;

import com.cloudpay360.model.PaymentRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<PaymentRequest, String> {
}