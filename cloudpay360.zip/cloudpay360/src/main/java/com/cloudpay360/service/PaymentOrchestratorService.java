package com.cloudpay360.service;

import com.cloudpay360.model.PaymentRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class PaymentOrchestratorService {

    @Autowired
    private FraudDetectionService fraudDetectionService;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Autowired
    private KafkaTemplate<String, PaymentRequest> kafkaTemplate;

    public void processPayment(PaymentRequest request) {
        System.out.println("Processing payment for order: " + request.getOrderId());

        // Cache payment request
        redisTemplate.opsForValue().set("payment:" + request.getOrderId(), request.getStatus());

        // Fraud detection
        if (fraudDetectionService.analyze(request)) {
            request.setStatus("APPROVED");
            // Save to database
            paymentRepository.save(request);
            // Publish to Kafka
            kafkaTemplate.send("payment-events", request.getOrderId(), request);
            // Assume Dashboard is updated via Kafka consumer
        } else {
            request.setStatus("REJECTED");
            paymentRepository.save(request);
            System.out.println("Fraud detected for order: " + request.getOrderId());
        }
    }
}