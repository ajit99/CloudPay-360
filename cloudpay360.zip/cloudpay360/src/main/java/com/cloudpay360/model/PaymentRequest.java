package com.cloudpay360.model;

import lombok.Data;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class PaymentRequest {
    @Id
    private String orderId;
    private double amount;
    private String currency;
    private String userId;
    private String status; // e.g., PENDING, APPROVED, REJECTED
}