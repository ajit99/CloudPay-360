package com.cloudpay360.model;

import lombok.Data;

@Data
public class User {
    private String userId;
    private String token; // Simulated JWT or OAuth token
}